library(tidyverse)
library(randomForest)
library(permimp)

### importing data and such
df_survey <- read_csv("clua_main.csv") %>% 
  mutate(farm_size_agric_ha = ifelse(measurement_unit_agric == 4, farm_size_agric/247.1, ifelse(measurement_unit_agric == 3, farm_size_agric, ifelse(measurement_unit_agric == 2, farm_size_agric/2.471, ifelse(measurement_unit_agric == 1, farm_size_agric/1000, NA))))) %>% ## adding farm size in ha
  mutate(farmer_gender = as.factor(farmer_gender), farmer_educ = as.factor(farmer_educ), marital_status = as.factor(marital_status), migration_info = as.factor(migration_info), farmer_group = as.factor(farmer_group), district = as.factor(district), climate_change <- as.factor(climate_change)) %>%   ## recoding some important variables as factors
  mutate(district = case_match(district, "1" ~ "ATP", "2" ~ "ASR", "3" ~ "WG"), farmer_gender = case_match(farmer_gender, "1" ~ "woman", "2" ~ "man"), farmer_educ = case_match(farmer_educ, "0" ~ "none", "1" ~ "primary", "2" ~ "secondary", "3" ~ "tertiary"), farmer_group = case_match(farmer_group, "1"~"Yes", "0"~"No"))  ## renaming the factors, here you can also reduce them, like if there are lots of obervations of codes 1 and 2 but just a few of 3,4,5, you can recode 3,4,5 as "other" and reduce the number of levels of the factor

## making a random forest (here I have just made a small and random question)

## making a dataframe
df_sub1 <- df_survey %>% select(farmer_gender, farmer_age, farm_size_agric_ha, farmer_educ, climate_change)
## can play here with the mtry and ntree
model_1 <- randomForest(as.factor(climate_change) ~ ., data = df_sub1, mtry = 2, ntree = 1000, keep.forest=TRUE, keep.inbag=TRUE, proximity = TRUE)

## to see model output
model_1

## to see factor importance
model_1$importance

## to calculate permutation importance
perm_1 <- permimp(model_1, do_check = F)

## to see permutation importance
perm_1$values

#### other code:

## to compare a negative binomial model to a poission model (NB assumes overdispersion in the data compared to poisson)
anova(m1,m2) ## where m1 is the poisson model and m2 is the negative binomial model
pchisq(2 * (logLik(m2) - logLik(m1)), df = 1, lower.tail = FALSE)
## a significant likelihood mean NB fits better than poisson

## to calculate McFadden's pseudo R-squared value
with(summary(m1), 1 - deviance/null.deviance)

## to calculate dispersion of the model:
E2 <- resid(m1, type = "pearson")
N  <- nrow(df_sub1) ##substitute data frame name
p  <- length(coef(m1))   
sum(E2^2) / (N - p)
## or
sum((resid(m1, type = "pearson"))^2)/(nrow(dd_sub1) - length(coef(m1)))
